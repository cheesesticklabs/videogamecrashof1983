Javatari for Javascript!
